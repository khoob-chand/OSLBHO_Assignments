<?php 
namespace Drupal\postapi\services;
class Test implements Postinterface {
  public function create($data,$uid)
  {
  }
  public function delete($data,$uid)
  {
  }
  public function update($data,$uid)
  {
  }
  public function read($uid){
    $entity_manager = \Drupal::entityTypeManager()->getStorage('profile')->loadMultiple();
    $target=$entity_manager[$uid]->get('field_test')->target_id;
    $paras = $entity_manager[$uid]->get('field_test')->entity->get('field_testname')->entity->name->value;
    $datas=[
      'testname'=>$paras,
      'id'=>$target,

    ];
    return $datas ;

  }




}